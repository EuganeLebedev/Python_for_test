from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.http import require_http_methods, require_GET, require_POST
from django.views import View
from django.views.generic.base import TemplateView
from django.views.generic import ListView, DetailView

from blog.models import Post

# Create your views here.

class BlogView(ListView):
    #model = Post
    queryset = Post.objects.filter(headline_image__isnull=False).order_by('title').all()
    context_object_name = "posts"


class BlogImagesView(ListView):
    context_object_name = "posts"

    def get_queryset(self):
        has_image = self.kwargs['has_image'] == 1

        return Post.objects.filter(headline_image__isnull=has_image).all()

class BlogPostView(DetailView):
    queryset = Post.objects.all()


class MyView(View):

    def get(self, request):
        return HttpResponse("class based view")

    def post(self, request):
        return HttpResponse("post cbv")


class MyTemplateView(TemplateView):
    template_name = "blog/my_template.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        posts = Post.objects.all()
        context['my_variable'] = 1231234234
        context['posts'] = posts

        return context


def index(request):
    return HttpResponse("Blog index")

def post_by_id(request, post_id):
    return HttpResponse(str(Post.objects.get(pk=post_id)))

def post_by_title(request, post_name):
    return HttpResponse(post_name)

@require_http_methods(["POST"])
def post_by_date(request, post_date, day):
    return HttpResponse(f"year: {post_date}, day: {day}")

def not_found(request, exception):
    return HttpResponse("NOT FOUND!!!")
