from django.db import models

# Create your models here.

ARTICLE_TYPES = [
    ('ARTICLE', 'Article'),
    ('LONGREAD', 'Longread'),
]

class AuthorManager(models.Manager):
    def get_queryset(self):
        qs = super().get_queryset()
        return qs.filter(pk=100)

class Author(models.Model):
    name = models.CharField(max_length=150)

    objects = AuthorManager()


class PostDescription(models.Model):
    description = models.TextField()


class PostManager(models.Manager):
    def with_headlines(self):
        return self.get_queryset().filter(headline_image__isnull=False)


class PostWithHeadlinesManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(headline_image__isnull=False)


class Post(models.Model):
    title = models.CharField(max_length=150)
    content = models.TextField()

    article_type = models.CharField('Type', max_length=100, choices=ARTICLE_TYPES)
    headline_image = models.ImageField(null=True, blank=True)
    description = models.OneToOneField(PostDescription, on_delete=models.CASCADE, null=True)

    authors = models.ManyToManyField(Author, null=True, blank=True)

    objects = PostManager()
    with_headlines = PostWithHeadlinesManager()

    def __str__(self):
        return self.title

    class Meta:
        indexes = [
            models.Index(fields=["title"])
        ]


class Comment(models.Model):
    comment_id = models.AutoField(primary_key=True)
    post = models.ForeignKey(Post, on_delete=models.CASCADE)

