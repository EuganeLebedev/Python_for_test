from django.urls import path, register_converter, re_path

from blog import views

class YearConverter:
    regex = '[0-9]{4}'

    def to_python(self, value):
        return int(value) + 2000

    def to_url(self, value):
        return f"{value}"

app_name = "blog"

register_converter(YearConverter, 'yyyy')

urlpatterns = [
    path("", views.index, name="index"),
    path("posts/<int:post_id>", views.post_by_id, name="post"),
    path("posts/<slug:post_name>", views.post_by_title, name="post_title"),
    path("posts/year/<yyyy:post_date>/<int:day>", views.post_by_date, name="post_date"),
    path("cbv", views.MyView.as_view()),
    path("template", views.MyTemplateView.as_view()),
    path("blog/", views.BlogView.as_view()),
    path("blog_images/<int:has_image>", views.BlogImagesView.as_view()),
    path("blog/<int:pk>", views.BlogPostView.as_view()),
]

