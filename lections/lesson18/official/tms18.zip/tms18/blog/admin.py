from django.contrib import admin

from blog.models import Post, Comment, PostDescription, Author
# Register your models here.

admin.site.register([Post, Comment, PostDescription, Author])

