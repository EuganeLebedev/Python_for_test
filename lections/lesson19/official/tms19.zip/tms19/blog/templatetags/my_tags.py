from datetime import datetime

from django import template

register = template.Library()

@register.simple_tag(name="current_time")
def current_time():
    return datetime.now()

@register.inclusion_tag('blog/current_time.html')
def current_time_template():
    return {
        "time": datetime.now(),
    }

@register.inclusion_tag("blog/post_comments.html")
def comments(post):
    return {
        "comments": post.comment_set.all()
    }
