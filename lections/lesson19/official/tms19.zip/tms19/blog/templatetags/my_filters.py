from django import template

register = template.Library()

@register.filter(name='my_lower_filter')
def my_lower(value, text):
    return text + value.lower()

