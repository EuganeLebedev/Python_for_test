from django import forms

from blog.models import Post

class PostForm(forms.Form):
    title = forms.CharField(label="Title", max_length=10)
    content = forms.CharField(label="Content", widget=forms.Textarea)

class PostModelForm(forms.ModelForm):
    class Meta:
        model = Post
        exclude = []
