from django.urls import path

from blog import views

app_name = "blog"

urlpatterns = [
    path("", views.IndexView.as_view(), name="index"),
    path("post/<int:pk>", views.PostView.as_view(), name="post"),
    path("post", views.post_new, name="post_new"),
    path("post_auto", views.PostCreateView.as_view(), name="post_new_auto"),
    path("post_auto/<int:pk>", views.PostUpdateView.as_view(), name="post_update_auto"),
]

