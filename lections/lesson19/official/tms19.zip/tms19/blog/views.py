from django.shortcuts import render, redirect
from django.urls import reverse, reverse_lazy
from django.http import HttpResponse
from django.views.decorators.http import require_http_methods, require_GET, require_POST
from django.views import View
from django.views.generic.base import TemplateView
from django.views.generic import ListView, DetailView
from django.views.generic.edit import CreateView, UpdateView

from blog.models import Post
from blog.forms import PostForm, PostModelForm

# Create your views here.

class IndexView(ListView):
    model = Post
    context_object_name = "posts"
    template_name = "blog/index.html"


class PostView(DetailView):
    model = Post
    template_name = "blog/post.html"


def post_new(request):
    if request.method == 'POST':
        form = PostModelForm(request.POST)
        if form.is_valid():
            post = form.save()
            return redirect(reverse("blog:post", kwargs={ "pk": post.id }))
        else:
            context = {
                "form": form,
            }
            return render(request, "blog/post_new_model_form.html", context)
    else:
        context = {
            "form": PostModelForm(),
        }
        return render(request, "blog/post_new_model_form.html", context)

class PostCreateView(CreateView):
    model = Post
    fields = ["title", "content"]


class PostUpdateView(UpdateView):
    model = Post
    fields = ["title", "content"]

